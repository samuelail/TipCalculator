//
//  ViewController.swift
//  TipCalculator
//
//  Created by Kingjulian on 12/27/17.
//  Copyright © 2017 sonar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    // Create outlets for the text field and tip label
    @IBOutlet weak var textBox: UITextField!
    @IBOutlet weak var tipLabel: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var tipSegment: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
       
    }
    // Hide the keyboard once you tap the view
    @IBAction func onTap(_ sender: Any) {
        view.endEditing(true)
    }
    @IBAction func calcTip(_ sender: Any) {
        //create a viarable called amount as a double
        // create a variable called tip which is 20%
        // create a variable for total which is tip + amount
        // create an array of possible tips so we can use our segment control
        let possTips = [0.2,0.3,0.5]
        
        let amount = Double(textBox.text!) ?? 0
        let tip = amount * possTips[tipSegment.selectedSegmentIndex]
        let total = tip + amount
        
        tipLabel.text = String(format: "$%.2f",tip)
        totalLabel.text = String(format: "$%.2f",total)
    }
    
  
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

